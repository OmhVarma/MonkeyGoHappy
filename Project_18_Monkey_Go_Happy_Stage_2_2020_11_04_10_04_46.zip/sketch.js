var PLAY = 1;
var gamestate = 1;
var monkey;
var banana, banana1;
var ground, ground1;
var obstacle, obstacle1;
var foodG, obstacleG;
var score;

function preload() {

  banana1 = loadImage('banana.png');

  obstacle1 = loadImage('stone.png');

  ground1 = loadImage('jungle.jpg');

}

function setup() {
  createCanvas(600, 400);

  monkey = createSprite(80, 305, 20, 20);
  monkey.addAnimation("Monkey_01.png", "Monkey_02.png", "Monkey_03.png", "Monkey_04.png", "Monkey_05.png", "Monkey_06.png", "Monkey_07.png", "Monkey_08.png", "Monkey_09.png", "Monkey_10.png");
  monkey.scale = 0.1;

  ground = createSprite(0, 5, 1200, 800);
  ground.addImage(ground1);
  ground.velocityX = -4;
  ground.scale = 1.2;

  ground1 = createSprite(0, 350, 1200, 20);
  ground1.velocityX = -4;
  ground1.visible = false;

  foodG = new Group();
  obstacleG = new Group();

  score = 0;

}

function draw() {

  background('white');

  //monkey.depth = obstacle.depth + 1;

  monkey.depth = ground.depth + 1;

  console.log();

  if (score === 4) {
    monkey.scale = 0.110;
  } else if (score === 8) {
    monkey.scale = 0.120;
  } else if (score === 12) {
    monkey.scale = 0.130;
  }

  if (obstacleG.isTouching(monkey)) {
    monkey.scale = 0.09;
  }

  if (foodG.isTouching(monkey)) {
    score = score + 1;

    foodG.destroyEach();
  }

  if (gamestate === PLAY) {
    spawnB();
    spawnO();
  }

  if (keyDown("space")) {
    monkey.velocityY = -10;
  }

  monkey.velocityY = monkey.velocityY + 1;

  monkey.collide(ground1);

  if (ground1.x < 0) {
    ground1.x = ground1.width / 2;
  }

  if (ground.x < 0) {
    ground.x = ground.width / 2;
  }

  drawSprites();

  textSize(17);
  stroke('white');
  text('Score: ' + score, 500, 20);

}

function spawnO() {
  if (frameCount % 300 === 0) {
    var obstacle = createSprite(600, 330, 20, 20);
    obstacle.velocityX = -4;
    obstacle.addImage(obstacle1);
    obstacle.lifetime = 600;
    obstacle.scale = 0.3;

    //monkey.depth = obstacle.depth + 1;

    obstacleG.add(obstacle);
  }


}

function spawnB() {
  if (frameCount % 140 === 0) {
    banana = createSprite(600, 200, 20, 20);
    banana.y = random(120, 200);
    banana.velocityX = -4;
    banana.scale = 0.040;
    banana.addImage(banana1);
    banana.lifetime = 600;

    monkey.depth = banana.depth + 1;

    foodG.add(banana);

  }
}